import React from 'react';

function App() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-800 font-sans">
      <div className="max-w-3xl mx-auto px-5 py-8">
        {/* Header Section */}
        <header className="text-center mb-10">
          <h1 className="text-4xl font-semibold mb-1">Welcome to Our Site</h1>
          <p className="text-lg text-gray-600">Your go-to destination for amazing content</p>
        </header>

        {/* Main Content */}
        <main>
          <section className="mb-8">
            <h2 className="text-2xl font-semibold border-b-2 border-gray-200 pb-2 mb-4">
              About Us
            </h2>
            <p className="leading-relaxed">
              We're dedicated to providing the best experience for our users. Our platform
              combines elegant design with powerful functionality to meet all your needs.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold border-b-2 border-gray-200 pb-2 mb-4">
              Our Services
            </h2>
            <p className="leading-relaxed">
              Discover our range of services designed to help you succeed. 
              <a href="#" className="text-blue-600 hover:underline ml-1">
                Learn more about what we offer
              </a>.
            </p>
          </section>
        </main>
      </div>
    </div>
  );
}

export default App;