import React, { useState } from 'react';
import { Code2, Briefcase, User2, Mail, ChevronRight, Github, Linkedin, ExternalLink } from 'lucide-react';

function App() {
  const [activeSection, setActiveSection] = useState('projects');

  const projects = [
    {
      title: "E-Commerce Platform",
      description: "A full-stack e-commerce solution built with React and Node.js",
      image: "https://images.unsplash.com/photo-1661956602116-aa6865609028?auto=format&fit=crop&q=80&w=800",
      tags: ["React", "Node.js", "MongoDB"],
      link: "#"
    },
    {
      title: "AI Image Generator",
      description: "An AI-powered image generation tool using stable diffusion",
      image: "https://images.unsplash.com/photo-1678911820864-e2c567c655d7?auto=format&fit=crop&q=80&w=800",
      tags: ["Python", "TensorFlow", "React"],
      link: "#"
    },
    {
      title: "Task Management App",
      description: "A beautiful and intuitive task management application",
      image: "https://images.unsplash.com/photo-1484480974693-6ca0a78fb36b?auto=format&fit=crop&q=80&w=800",
      tags: ["React", "Firebase", "Tailwind"],
      link: "#"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-white">
      {/* Navigation */}
      <nav className="fixed bottom-8 left-1/2 transform -translate-x-1/2 bg-gray-800/50 backdrop-blur-lg rounded-full px-6 py-3 border border-gray-700/50">
        <ul className="flex space-x-8">
          <li>
            <button 
              onClick={() => setActiveSection('projects')}
              className={`flex items-center space-x-2 ${activeSection === 'projects' ? 'text-blue-400' : 'text-gray-400'} hover:text-blue-400 transition-colors`}
            >
              <Code2 size={20} />
              <span>Projects</span>
            </button>
          </li>
          <li>
            <button 
              onClick={() => setActiveSection('about')}
              className={`flex items-center space-x-2 ${activeSection === 'about' ? 'text-blue-400' : 'text-gray-400'} hover:text-blue-400 transition-colors`}
            >
              <User2 size={20} />
              <span>About</span>
            </button>
          </li>
          <li>
            <button 
              onClick={() => setActiveSection('contact')}
              className={`flex items-center space-x-2 ${activeSection === 'contact' ? 'text-blue-400' : 'text-gray-400'} hover:text-blue-400 transition-colors`}
            >
              <Mail size={20} />
              <span>Contact</span>
            </button>
          </li>
        </ul>
      </nav>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-20">
        {/* Hero Section */}
        <div className="text-center mb-20 pt-10">
          <h1 className="text-5xl font-bold mb-6 bg-gradient-to-r from-blue-400 to-purple-500 text-transparent bg-clip-text">
            John Doe
          </h1>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            Full Stack Developer crafting digital experiences with passion and precision
          </p>
          <div className="flex justify-center space-x-4 mt-8">
            <a href="#" className="text-gray-400 hover:text-white transition-colors">
              <Github size={24} />
            </a>
            <a href="#" className="text-gray-400 hover:text-white transition-colors">
              <Linkedin size={24} />
            </a>
          </div>
        </div>

        {/* Projects Section */}
        {activeSection === 'projects' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <div key={index} className="group relative bg-gray-800 rounded-xl overflow-hidden border border-gray-700/50 hover:border-blue-500/50 transition-all duration-300">
                <div className="aspect-video overflow-hidden">
                  <img 
                    src={project.image} 
                    alt={project.title}
                    className="object-cover w-full h-full group-hover:scale-110 transition-transform duration-300"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-2">{project.title}</h3>
                  <p className="text-gray-400 mb-4">{project.description}</p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.tags.map((tag, tagIndex) => (
                      <span key={tagIndex} className="px-3 py-1 bg-gray-700/50 rounded-full text-sm">
                        {tag}
                      </span>
                    ))}
                  </div>
                  <a 
                    href={project.link}
                    className="inline-flex items-center text-blue-400 hover:text-blue-300"
                  >
                    View Project <ChevronRight size={16} className="ml-1" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* About Section */}
        {activeSection === 'about' && (
          <div className="max-w-3xl mx-auto">
            <div className="bg-gray-800/50 rounded-xl p-8 backdrop-blur-lg border border-gray-700/50">
              <h2 className="text-3xl font-bold mb-6">About Me</h2>
              <p className="text-gray-300 mb-6">
                I'm a passionate Full Stack Developer with 5 years of experience in building web applications.
                My journey in tech started with a curiosity about how things work on the internet, and that
                curiosity has evolved into a career crafting digital experiences that make a difference.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <h3 className="text-xl font-semibold mb-4">Skills</h3>
                  <div className="flex flex-wrap gap-2">
                    {["JavaScript", "TypeScript", "React", "Node.js", "Python", "AWS", "Docker"].map((skill, index) => (
                      <span key={index} className="px-3 py-1 bg-gray-700/50 rounded-full text-sm">
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-4">Experience</h3>
                  <ul className="space-y-4">
                    <li className="flex items-start">
                      <Briefcase size={20} className="mr-2 mt-1 text-blue-400" />
                      <div>
                        <h4 className="font-medium">Senior Developer at TechCorp</h4>
                        <p className="text-gray-400">2020 - Present</p>
                      </div>
                    </li>
                    <li className="flex items-start">
                      <Briefcase size={20} className="mr-2 mt-1 text-blue-400" />
                      <div>
                        <h4 className="font-medium">Full Stack Developer at StartupX</h4>
                        <p className="text-gray-400">2018 - 2020</p>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Contact Section */}
        {activeSection === 'contact' && (
          <div className="max-w-xl mx-auto">
            <div className="bg-gray-800/50 rounded-xl p-8 backdrop-blur-lg border border-gray-700/50">
              <h2 className="text-3xl font-bold mb-6">Get in Touch</h2>
              <form className="space-y-6">
                <div>
                  <label className="block text-sm font-medium mb-2">Name</label>
                  <input 
                    type="text"
                    className="w-full px-4 py-2 bg-gray-700/50 rounded-lg border border-gray-600 focus:border-blue-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Email</label>
                  <input 
                    type="email"
                    className="w-full px-4 py-2 bg-gray-700/50 rounded-lg border border-gray-600 focus:border-blue-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Message</label>
                  <textarea 
                    rows={4}
                    className="w-full px-4 py-2 bg-gray-700/50 rounded-lg border border-gray-600 focus:border-blue-500 focus:outline-none"
                  ></textarea>
                </div>
                <button 
                  type="submit"
                  className="w-full bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded-lg transition-colors"
                >
                  Send Message
                </button>
              </form>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

export default App;